# Contributor Covenant Code of Conduct
## Our Pledge
We pledge to make participation in our community a harassment-free experience for everyone.
## Our Standards
- Be respectful and kind.
- Respect differing opinions.
- Give and gracefully accept constructive feedback.
## Enforcement
Report any abusive or harassing behavior to [your-email@example.com].
This Code of Conduct is adapted from the [Contributor Covenant](https://www.contributor-covenant.org/).